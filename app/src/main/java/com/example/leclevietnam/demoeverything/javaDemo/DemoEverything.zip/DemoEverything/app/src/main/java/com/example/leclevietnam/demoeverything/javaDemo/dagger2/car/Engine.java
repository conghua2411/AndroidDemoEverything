package com.example.leclevietnam.demoeverything.javaDemo.dagger2.car;

public interface Engine {
    void start();
}
