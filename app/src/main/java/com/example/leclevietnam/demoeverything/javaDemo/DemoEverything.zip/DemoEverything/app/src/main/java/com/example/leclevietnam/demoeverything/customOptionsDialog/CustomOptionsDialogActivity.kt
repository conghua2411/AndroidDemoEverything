package com.example.leclevietnam.demoeverything.customOptionsDialog

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.example.leclevietnam.demoeverything.R

class CustomOptionsDialogActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_custom_options_dialog)
    }
}
