package com.example.leclevietnam.demoeverything.javaDemo.dagger2.car;

import javax.inject.Inject;
import javax.inject.Singleton;

//@Singleton
public class Driver {

//    @Inject
//    public Driver() {
//
//    }
}
