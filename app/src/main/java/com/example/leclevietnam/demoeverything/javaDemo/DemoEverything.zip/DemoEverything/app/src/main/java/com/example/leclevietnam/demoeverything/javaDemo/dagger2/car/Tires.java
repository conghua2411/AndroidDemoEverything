package com.example.leclevietnam.demoeverything.javaDemo.dagger2.car;

import android.util.Log;

public class Tires {

    public Tires() {
        Log.d("Dagger", "Tires: ");
    }

    public void inflate() {
        Log.d("Dagger", "tires inflate: ");
    }
}
