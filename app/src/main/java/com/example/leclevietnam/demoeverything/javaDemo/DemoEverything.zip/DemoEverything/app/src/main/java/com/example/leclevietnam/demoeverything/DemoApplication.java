package com.example.leclevietnam.demoeverything;

import android.app.Application;

import com.example.leclevietnam.demoeverything.javaDemo.dagger2.dagger.AppComponent;
import com.example.leclevietnam.demoeverything.javaDemo.dagger2.dagger.DaggerAppComponent;

public class DemoApplication extends Application {

//    private ActivityComponent carComponent;

    private AppComponent appComponent;

    @Override
    public void onCreate() {
        super.onCreate();

//        carComponent = DaggerActivityComponent.builder()
//                .housePower(100)
//                .engineCapacity(1000)
//                .build();

        appComponent = DaggerAppComponent.create();

    }

//    public ActivityComponent getCarComponent() {
//        return carComponent;
//    }

    public AppComponent getAppComponent() {
        return appComponent;
    }
}
